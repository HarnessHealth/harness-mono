class MalformedPDFException(Exception):
    pass


class PdfminerException(Exception):
    pass
