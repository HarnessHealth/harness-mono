version_info = (0, 11, 7)
__version__ = ".".join(map(str, version_info))
